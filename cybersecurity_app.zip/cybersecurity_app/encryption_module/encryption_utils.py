from Crypto.Cipher import AES, DES
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import base64
import os

def aes_encrypt(data, key):
    cipher = AES.new(key.encode('utf-8'), AES.MODE_EAX)
    ciphertext, tag = cipher.encrypt_and_digest(data.encode('utf-8'))
    return base64.b64encode(cipher.nonce + ciphertext).decode('utf-8')

def des_encrypt(data, key):
    cipher = DES.new(key.encode('utf-8'), DES.MODE_ECB)
    padded_data = data + (8 - len(data) % 8) * ' '  # Padding to multiple of 8
    ciphertext = cipher.encrypt(padded_data.encode('utf-8'))
    return base64.b64encode(ciphertext).decode('utf-8')

def rsa_encrypt(data):
    key = RSA.generate(2048)
    public_key = key.publickey()
    cipher = PKCS1_OAEP.new(public_key)
    ciphertext = cipher.encrypt(data.encode('utf-8'))
    return base64.b64encode(ciphertext).decode('utf-8')
