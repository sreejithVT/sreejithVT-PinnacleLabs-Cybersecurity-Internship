from django.urls import path
from . import views

urlpatterns = [
    path('', views.encryption_view, name='encryption_view'),
]
