from django.shortcuts import render
from . import encryption_utils
from .forms import EncryptionForm

def encryption_view(request):
    result = ''
    form = EncryptionForm()

    if request.method == 'POST':
        form = EncryptionForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data['data']
            key = form.cleaned_data['key']
            enc_type = form.cleaned_data['enc_type']

            if enc_type == 'AES':
                if len(key) not in [16, 24, 32]:
                    result = 'Error: AES key must be 16, 24, or 32 characters long.'
                else:
                    result = encryption_utils.aes_encrypt(data, key)

            elif enc_type == 'DES':
                if len(key) != 8:
                    result = 'Error: DES key must be exactly 8 characters long.'
                else:
                    result = encryption_utils.des_encrypt(data, key)

            elif enc_type == 'RSA':
                result = encryption_utils.rsa_encrypt(data)

            else:
                result = 'Invalid encryption type selected.'

    return render(request, 'encryption.html', {'form': form, 'result': result})

