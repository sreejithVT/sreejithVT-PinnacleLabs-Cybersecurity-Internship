from django import forms

class EncryptionForm(forms.Form):
    ENC_CHOICES = [
        ('AES', 'AES Encryption'),
        ('DES', 'DES Encryption'),
        ('RSA', 'RSA Encryption'),
    ]

    data = forms.CharField(widget=forms.Textarea(attrs={'rows': 4, 'cols': 50}), label='Data to Encrypt')
    key = forms.CharField(max_length=32, required=False, help_text='AES: 16/24/32 chars | DES: 8 chars | RSA: No key needed')
    enc_type = forms.ChoiceField(choices=ENC_CHOICES, label='Encryption Type')
