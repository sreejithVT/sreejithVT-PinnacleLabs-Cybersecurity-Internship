from django.urls import path
from . import views

urlpatterns = [
    path('', views.keylogger_view, name='keylogger'),
]
