from django import forms

class KeyloggerForm(forms.Form):
    action = forms.ChoiceField(choices=[('start', 'Start'), ('stop', 'Stop')], required=True)
