from django import forms

class ImageUploadForm(forms.Form):
    image = forms.ImageField()

class EncryptedFileForm(forms.Form):
    encrypted_file = forms.FileField()
