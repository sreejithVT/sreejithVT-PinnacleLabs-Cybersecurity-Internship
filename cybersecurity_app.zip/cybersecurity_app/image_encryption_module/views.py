from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, FileResponse
from cryptography.fernet import Fernet
import os

# Key for encryption/decryption (In production, securely store it)
key = Fernet.generate_key()
cipher_suite = Fernet(key)

MEDIA_ROOT = 'media/'

def image_home(request):
    return render(request, 'image_home.html')

def encrypt_image(request):
    if request.method == 'POST' and request.FILES['image']:
        image = request.FILES['image']
        fs = FileSystemStorage(location=MEDIA_ROOT)
        image_path = fs.save(image.name, image)
        image_full_path = os.path.join(MEDIA_ROOT, image_path)

        with open(image_full_path, 'rb') as f:
            original_data = f.read()

        encrypted_data = cipher_suite.encrypt(original_data)
        encrypted_filename = f'encrypted_{image.name}.bin'
        encrypted_path = os.path.join(MEDIA_ROOT, encrypted_filename)

        with open(encrypted_path, 'wb') as f:
            f.write(encrypted_data)

        os.remove(image_full_path)

        return render(request, 'encryption_success.html', {
            'encrypted_file': encrypted_filename
        })
    return redirect('image_home')

def decrypt_image(request):
    if request.method == 'POST' and request.FILES['encrypted_file']:
        encrypted_file = request.FILES['encrypted_file']
        fs = FileSystemStorage(location=MEDIA_ROOT)
        encrypted_path = fs.save(encrypted_file.name, encrypted_file)
        encrypted_full_path = os.path.join(MEDIA_ROOT, encrypted_path)

        with open(encrypted_full_path, 'rb') as f:
            encrypted_data = f.read()

        try:
            decrypted_data = cipher_suite.decrypt(encrypted_data)
        except Exception as e:
            return HttpResponse(f"Decryption failed: {str(e)}")

        decrypted_filename = f'decrypted_{encrypted_file.name}.png'
        decrypted_path = os.path.join(MEDIA_ROOT, decrypted_filename)

        with open(decrypted_path, 'wb') as f:
            f.write(decrypted_data)

        return render(request, 'decryption_success.html', {
            'decrypted_file': decrypted_filename
        })
    return redirect('image_home')
