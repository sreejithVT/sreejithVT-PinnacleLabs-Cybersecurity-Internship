from django.urls import path
from . import views

urlpatterns = [
    path('', views.image_home, name='image_home'),
    path('encrypt/', views.encrypt_image, name='encrypt_image'),
    path('decrypt/', views.decrypt_image, name='decrypt_image'),
]
