from django.shortcuts import render
import re
import math

common_passwords = ['password', '123456', '12345678', 'qwerty', 'abc123', 'admin', 'letmein', 'welcome']

def password_entropy(password):
    pool = 0
    if re.search(r'[a-z]', password):
        pool += 26
    if re.search(r'[A-Z]', password):
        pool += 26
    if re.search(r'\d', password):
        pool += 10
    if re.search(r'\W', password):
        pool += 32
    entropy = len(password) * math.log2(pool) if pool else 0
    return round(entropy, 2)

def password_analyzer(request):
    context = {}
    if request.method == 'POST':
        password = request.POST.get('password', '')
        feedback = []
        strength_score = 0
        issues = []

        # Minimum length
        if len(password) >= 8:
            strength_score += 1
        else:
            issues.append("❌ Password is less than 8 characters.")

        # Character Variety
        checks = {
            "Uppercase": bool(re.search(r'[A-Z]', password)),
            "Lowercase": bool(re.search(r'[a-z]', password)),
            "Number": bool(re.search(r'\d', password)),
            "Special Character": bool(re.search(r'\W', password)),
        }
        strength_score += sum(checks.values())

        # Missing character feedback
        for char_type, present in checks.items():
            if not present:
                issues.append(f"❌ Missing {char_type} characters.")

        # Common Password Detection
        if password.lower() in common_passwords:
            issues.append("❌ Password is too common.")
        else:
            strength_score += 1

        # Dictionary Words Detection (Simple check)
        if re.search(r'\b(the|and|password|admin|user)\b', password.lower()):
            issues.append("❌ Contains dictionary words.")
        else:
            strength_score += 1

        # Repetitive Character Detection
        if re.search(r'(.)\1{2,}', password):
            issues.append("❌ Contains repetitive characters (e.g., 'aaa').")
        else:
            strength_score += 1

        # Sequential Characters Detection
        if re.search(r'012|123|234|345|456|567|678|789|890|abc|bcd|cde|def|efg|fgh|qwe|wer|ert|rty|tyu|yui|uio', password.lower()):
            issues.append("❌ Contains sequential or keyboard pattern characters.")
        else:
            strength_score += 1

        # Personal Info (Dummy Check)
        if re.search(r'(199\d|200\d|202\d|\d{10}|\w+@\w+\.\w+)', password):
            issues.append("❌ Contains personal info (year, phone, or email).")
        else:
            strength_score += 1

        # Entropy Calculation
        entropy_score = password_entropy(password)

        # Final Feedback
        context.update({
            'password': password,
            'issues': issues,
            'strength_score': strength_score,
            'entropy_score': entropy_score,
            'checks': checks,
        })
    return render(request, 'password_analyzer.html', context)

