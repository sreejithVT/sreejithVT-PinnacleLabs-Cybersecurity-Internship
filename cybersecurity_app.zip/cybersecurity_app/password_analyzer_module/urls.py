from django.urls import path
from . import views

urlpatterns = [
    path('', views.password_analyzer, name='password_analyzer'),
]
