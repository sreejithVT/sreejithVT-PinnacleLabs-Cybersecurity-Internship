console.log("Password Analyzer JS Loaded");
