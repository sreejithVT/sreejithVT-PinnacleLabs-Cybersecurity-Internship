document.addEventListener('DOMContentLoaded', function () {
    const methodField = document.getElementById('id_method');
    const keyInfo = document.getElementById('key-info');

    if (methodField) {
        methodField.addEventListener('change', function () {
            const method = this.value;
            if (method === 'AES') {
                keyInfo.textContent = "AES requires the secret key to be 16, 24, or 32 characters long.";
            } else if (method === 'DES') {
                keyInfo.textContent = "DES requires the secret key to be exactly 8 characters long.";
            } else if (method === 'RSA') {
                keyInfo.textContent = "RSA doesn't require a specific key length.";
            } else {
                keyInfo.textContent = "";
            }
        });
    }
});
