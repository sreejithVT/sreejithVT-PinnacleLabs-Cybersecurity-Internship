console.log("Keylogger Module Loaded");
